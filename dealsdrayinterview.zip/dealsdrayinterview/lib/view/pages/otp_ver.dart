
import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';


class HomePageWidget extends StatefulWidget {
  const HomePageWidget({super.key});

  @override
  State<HomePageWidget> createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();

  }

  @override
  void dispose() {


    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color(0xFFFCFCFC),
        automaticallyImplyLeading: false,
        title: Text(
          'Back',
          style: TextStyle(
            fontFamily: 'Outfit',
            color: Color(0xFF20117A),
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [],
        centerTitle: false,
        elevation: 2,
      ),
      body: SafeArea(
        top: true,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(
                    'assets/images/sheild.png',
                    width: 40,
                    height: 40,
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
            Padding(
              padding: EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Enter Code',
                    // style: FlutterFlowTheme.of(context).bodyMedium,
                  ),
                  Text(
                    'Your temporary log-in code was sent to',
                    //style: FlutterFlowTheme.of(context).bodyMedium,
                  ),
                  Text(
                    '70029-58902',
                    // style: FlutterFlowTheme.of(context).bodyMedium,
                  ),
                ],
              ),
            ),
            Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                PinCodeTextField(
                  autoDisposeControllers: false,
                  appContext: context,
                  length: 5,
                  // textStyle: FlutterFlowTheme.of(context).bodyLarge,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  enableActiveFill: false,
                  autoFocus: true,
                  enablePinAutofill: false,
                  errorTextSpace: 16,
                  showCursor: true,

                  obscureText: false,
                  keyboardType: TextInputType.number,
                  pinTheme: PinTheme(
                    fieldHeight: 44,
                    fieldWidth: 44,
                    borderWidth: 2,
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(12),
                      bottomRight: Radius.circular(12),
                      topLeft: Radius.circular(12),
                      topRight: Radius.circular(12),
                    ),

                    inactiveColor: Color(0xFFD3D0D0),


                    inactiveFillColor: Color(0xFFD3D0D0),

                  ),

                  onChanged: (_) {},
                  autovalidateMode: AutovalidateMode.onUserInteraction,

                ),
              ],
            ),
            RichText(
              textScaler: MediaQuery.of(context).textScaler,
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Didn\'t recieve a code?',
                    style: TextStyle(),
                  ),
                  TextSpan(
                    text: ' Send again',

                  )
                ],

              ),
            ),
          ],
        ),
      ),
    );
  }
}