import 'package:flutter/material.dart';


class WelcomePage extends StatefulWidget {
  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  int? _selectedIndex;

  Widget _buildPageIndicator(int pageIndex) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedIndex = pageIndex;
        });
      },
      child: Container(
        width: 10,
        height: 10,
        margin: EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _selectedIndex == pageIndex ? Colors.indigo : Colors.grey,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          color: Color(0XFFF3F3F3),
          child: Column(
            children: [
              Expanded(
                child: Image.asset('assests/tree.jpg'),
              ),
              Container(
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Welcome to the App',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Sama Gujarati'
                        ),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Here is a good place for a brief overview',
                        style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                      ),
                      Text(
                        'of the app and its key features',
                        style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                      ),
                      SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(3, (index) => _buildPageIndicator(index)),
                      ),
                      SizedBox(height: 40),
                      SizedBox(
                        width: 390, // Adjust width here
                        height: 54, // Adjust height here
                        child: ElevatedButton(
                          onPressed: () {

                          },
                          child: Text(
                            'Get Started',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: EdgeInsets.zero, // Remove padding
                            // Adjust gap here
                            visualDensity: VisualDensity(horizontal: 0, vertical: 0), // Adjust gap here
                            backgroundColor: Color(0XFF20117A), // Button background color
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}