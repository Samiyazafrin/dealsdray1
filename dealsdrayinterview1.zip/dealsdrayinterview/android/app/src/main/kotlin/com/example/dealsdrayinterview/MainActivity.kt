package com.example.dealsdrayinterview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
